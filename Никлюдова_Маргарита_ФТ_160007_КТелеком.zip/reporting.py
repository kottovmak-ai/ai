"""Выгрузка отчёта о состоянии сети в Excel (.xlsx)."""
import os
import platform
import subprocess
from collections import Counter
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart, PieChart, Reference
from openpyxl.chart.series import DataPoint
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from analytics import (METRICS, METRIC_RU, analyze_network, classify, current_streak, decision_support,
                       find_clusters, haversine_km, mass_outages, moving_average, period_stats,
                       problems_by_distance, state_durations)

CENTER = (56.8389, 60.6057)
ACCENT = "D21F5B"
HEADER_FILL = PatternFill("solid", fgColor=ACCENT)
HEADER_FONT = Font(bold=True, color="FFFFFF", name="Arial", size=10)
BODY_FONT = Font(name="Arial", size=10, color="29272B")
THIN = Side(style="thin", color="E7E5E8")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
STATUS_FILL = {
    "OK": PatternFill("solid", fgColor="E3EBF0"),
    "MEDIUM": PatternFill("solid", fgColor="F6E3E9"),
    "CRITICAL": PatternFill("solid", fgColor="FBD3E0"),
    "HIGH": PatternFill("solid", fgColor="FBD3E0"),
    "LOW": PatternFill("solid", fgColor="E3EBF0"),
}
STATUS_FONT = {
    "OK": Font(name="Arial", size=10, bold=True, color="3F5666"),
    "MEDIUM": Font(name="Arial", size=10, bold=True, color="8E4A60"),
    "CRITICAL": Font(name="Arial", size=10, bold=True, color=ACCENT),
    "HIGH": Font(name="Arial", size=10, bold=True, color=ACCENT),
    "LOW": Font(name="Arial", size=10, bold=True, color="3F5666"),
}
STATUS_RU = {"OK": "Норма", "MEDIUM": "Предупреждение", "CRITICAL": "Критично",
             "HIGH": "Высокий", "LOW": "Низкий"}


def _dt(value):
    try:
        return datetime.fromisoformat(value)
    except Exception:
        return value


def _table(ws, headers, rows, start_row=1, formats=None, status_cols=()):
    """Записывает таблицу с оформлением. formats: {индекс колонки: числовой формат}."""
    formats = formats or {}
    for c, h in enumerate(headers, 1):
        cell = ws.cell(row=start_row, column=c, value=h)
        cell.fill, cell.font, cell.border = HEADER_FILL, HEADER_FONT, BORDER
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[start_row].height = 32
    for r, row in enumerate(rows, start_row + 1):
        for c, value in enumerate(row, 1):
            cell = ws.cell(row=r, column=c, value=value)
            cell.font, cell.border = BODY_FONT, BORDER
            cell.alignment = Alignment(vertical="center", wrap_text=isinstance(value, str) and len(value) > 40)
            if c - 1 in formats:
                cell.number_format = formats[c - 1]
            if c - 1 in status_cols and value in STATUS_FILL:
                cell.fill, cell.font = STATUS_FILL[value], STATUS_FONT[value]
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif r % 2 == 1:
                cell.fill = PatternFill("solid", fgColor="FAFAFB")
    last_row = start_row + max(len(rows), 1)
    ws.auto_filter.ref = f"A{start_row}:{get_column_letter(len(headers))}{last_row}"
    ws.freeze_panes = ws.cell(row=start_row + 1, column=1)
    ws.sheet_view.showGridLines = False
    # ширина колонок по содержимому
    for c, h in enumerate(headers, 1):
        values = [str(h)] + [str(row[c - 1]) for row in rows if c - 1 < len(row) and row[c - 1] is not None]
        ws.column_dimensions[get_column_letter(c)].width = min(48, max(11, max(len(v) for v in values) + 3))


def export_excel(latest, histories, alerts, full=None, rejected=None):
    full = full if full is not None else histories
    rejected = rejected or []
    reports_dir = Path(__file__).resolve().parent / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    out = reports_dir / f"KTelecom_network_report_{stamp}.xlsx"

    wb = Workbook()
    states = {rid: classify(x) for rid, x in latest.items()}
    counts = Counter(states.values())
    districts = analyze_network(latest, histories)

    # ---- 1. Сводка ----
    ws = wb.active
    ws.title = "Сводка"
    ws.sheet_view.showGridLines = False
    ws["A1"] = "К-Телеком · отчёт о качестве интернет-соединения"
    ws["A1"].font = Font(name="Arial", size=16, bold=True, color=ACCENT)
    ws["A2"] = f"Сформирован: {datetime.now():%d.%m.%Y %H:%M}   ·   Екатеринбург и УрФО"
    ws["A2"].font = Font(name="Arial", size=10, color="77727A")
    kpi = [("Всего роутеров", len(latest)), ("В норме", counts.get("OK", 0)),
           ("Предупреждения", counts.get("MEDIUM", 0)), ("Критические", counts.get("CRITICAL", 0)),
           ("Оповещения", len(alerts))]
    clusters = find_clusters(latest)
    events, mass = mass_outages(latest, districts, clusters)
    kpi += [("Массовые нарушения", len(events)), ("Отклонено строк данных", len(rejected))]
    _table(ws, ["Показатель", "Значение"], kpi, start_row=4)
    ws.freeze_panes = None
    ws.auto_filter.ref = None
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 14
    data = Reference(ws, min_col=2, min_row=6, max_row=8)
    pie = PieChart()
    pie.title = "Статусы роутеров"
    pie.add_data(data, titles_from_data=False)
    pie.set_categories(Reference(ws, min_col=1, min_row=6, max_row=8))
    pie.height, pie.width = 7.5, 11
    for i, col in enumerate(["607889", "B86B83", ACCENT]):
        pt = DataPoint(idx=i)
        pt.graphicalProperties.solidFill = col
        pie.series[0].dPt.append(pt)
    ws.add_chart(pie, "D4")

    # ---- 2. Текущее состояние ----
    cur = wb.create_sheet("Текущее состояние")
    rows = []
    for rid, x in sorted(latest.items()):
        rows.append([rid, x["location"], x["district"], _dt(x["timestamp"]), x["ping_ms"], x["download_mbps"],
                     x["upload_mbps"], x["packet_loss"] / 100, x["jitter_ms"], states[rid],
                     x["lat"], x["lon"], round(haversine_km(CENTER[0], CENTER[1], x["lat"], x["lon"]), 2)])
    _table(cur, ["Роутер", "Адрес", "Район", "Время измерения", "Ping, мс", "Download, Мбит/с", "Upload, Мбит/с",
                 "Потери пакетов", "Jitter, мс", "Статус", "Широта", "Долгота", "До центра, км"], rows,
           formats={3: "DD.MM.YYYY HH:MM:SS", 4: "0.0", 5: "0.0", 6: "0.0", 7: "0.0%", 8: "0.0",
                    10: "0.000000", 11: "0.000000", 12: "0.00"}, status_cols={9})

    # ---- 3. История ----
    hist = wb.create_sheet("История")
    rows = [[rid, _dt(x["timestamp"]), x["ping_ms"], x["download_mbps"], x["upload_mbps"],
             x["packet_loss"] / 100, x["jitter_ms"], classify(x)]
            for rid in sorted(full) for x in full[rid]]
    _table(hist, ["Роутер", "Время", "Ping, мс", "Download, Мбит/с", "Upload, Мбит/с", "Потери пакетов",
                  "Jitter, мс", "Статус"], rows,
           formats={1: "DD.MM.YYYY HH:MM:SS", 2: "0.0", 3: "0.0", 4: "0.0", 5: "0.0%", 6: "0.0"}, status_cols={7})

    # ---- 4. Оповещения ----
    al = wb.create_sheet("Оповещения")
    rows = [[_dt(a["time"]), a["router_id"], a["district"], a["status"], a["message"]] for a in alerts]
    if not rows:
        rows = [["—", "—", "—", "—", "За время работы оповещений не было"]]
    _table(al, ["Время", "Роутер", "Район", "Статус", "Сообщение"], rows,
           formats={0: "DD.MM.YYYY HH:MM:SS"}, status_cols={3})

    # ---- 5. Аналитика районов ----
    an = wb.create_sheet("Аналитика районов")
    rows = [[d["district"], d["total"], d["problem"], d["critical"], d["share"] / 100, d["critical_share"] / 100, d["priority"]]
            for d in districts]
    _table(an, ["Район", "Всего роутеров", "Проблемных", "Критических", "Доля проблемных", "Доля критических",
                "Территориальный приоритет"], rows, formats={4: "0%", 5: "0%"}, status_cols={6})
    if rows:
        bar = BarChart()
        bar.type = "col"
        bar.title = "Проблемные роутеры по районам"
        bar.y_axis.title = "Количество"
        bar.add_data(Reference(an, min_col=3, max_col=4, min_row=1, max_row=len(rows) + 1), titles_from_data=True)
        bar.set_categories(Reference(an, min_col=1, min_row=2, max_row=len(rows) + 1))
        bar.height, bar.width = 8, 16
        bar.series[0].graphicalProperties.solidFill = "B86B83"
        bar.series[1].graphicalProperties.solidFill = ACCENT
        an.add_chart(bar, "I2")

    # ---- 6. Статистика за период ----
    stt = wb.create_sheet("Статистика за период")
    rows = []
    for rid in sorted(full):
        items = full[rid]
        st = period_stats(items); dur = state_durations(items); cur, run, problem = current_streak(items)
        row = [rid, items[0]["district"], _dt(items[0]["timestamp"]), _dt(items[-1]["timestamp"])]
        for m in METRICS:
            row += [round(st[m][0], 2), st[m][1], st[m][2], round(moving_average([x[m] for x in items])[-1], 2)]
        row += [dur["OK"], dur["MEDIUM"], dur["CRITICAL"], problem]
        rows.append(row)
    headers = ["Роутер", "Район", "Период с", "Период по"]
    for m in METRICS:
        short = METRIC_RU[m].split(",")[0]
        headers += [f"{short} сред.", f"{short} мин.", f"{short} макс.", f"{short} скольз. сред."]
    headers += ["В норме, мин", "Предупреждение, мин", "Критично, мин", "Текущее нарушение, мин"]
    _table(stt, headers, rows, formats={2: "HH:MM", 3: "HH:MM"})

    # ---- 7. Массовые нарушения и скопления ----
    ms = wb.create_sheet("Массовые нарушения")
    rows = [[ev["type"], ev["where"], ", ".join(ev["routers"]), ev["critical"], ev["reason"], "Да"] for ev in events]
    rows += [["Скопление", ", ".join(c["districts"]), ", ".join(c["routers"]), c["critical"],
              f"радиус {c['radius_km']:.1f} км, до центра {c['distance_km']:.1f} км", "Да" if c["mass"] else "Нет"]
             for c in clusters if not c["mass"]]
    if not rows:
        rows = [["—", "—", "—", 0, "Массовых нарушений не обнаружено", "Нет"]]
    _table(ms, ["Тип", "Где", "Устройства", "Критических", "Основание", "Массовое"], rows)

    # ---- 8. Проблемы по расстоянию ----
    pd = wb.create_sheet("Проблемы по расстоянию")
    rows = [[i, rid, x["location"], x["district"], s_, round(d, 2)] for i, (rid, x, s_, d) in enumerate(problems_by_distance(latest), 1)]
    _table(pd, ["№", "Роутер", "Адрес", "Район", "Статус", "До диспетчерского центра, км"], rows,
           formats={5: "0.00"}, status_cols={4})

    # ---- 9. Рекомендации ----
    rec = wb.create_sheet("Рекомендации")
    rows = [[i, r["router_id"], r["district"], r["status"], r["duration"], r["affected"], "Да" if r["mass"] else "Нет",
             round(r["distance_km"], 2), r["score"], r["recommendation"], r["reason"]]
            for i, r in enumerate(decision_support(latest, histories, districts), 1)]
    _table(rec, ["Приоритет", "Роутер", "Район", "Статус", "Длительность нарушения, мин", "Затронуто устройств",
                 "Массовая неисправность", "До центра, км", "Балл приоритета", "Рекомендация", "Обоснование"], rows,
           formats={7: "0.00", 8: "0.0"}, status_cols={3})

    # ---- 10. Ошибки данных ----
    er = wb.create_sheet("Ошибки данных")
    rows = [[r["line"], r["router_id"], r["timestamp"], r["errors"]] for r in rejected] or [["—", "—", "—", "Ошибок не обнаружено"]]
    _table(er, ["Строка файла", "Роутер", "Время", "Ошибки"], rows)

    wb.save(out)
    return str(out)


def open_file(path):
    """Открывает файл в программе по умолчанию (Excel / LibreOffice)."""
    try:
        if platform.system() == "Windows":
            os.startfile(path)  # type: ignore[attr-defined]
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass
