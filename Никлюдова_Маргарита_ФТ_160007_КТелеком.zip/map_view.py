"""Карта местности (OpenStreetMap) прямо внутри окна Flet.

Тайлы скачиваются с сервера OpenStreetMap и кэшируются в папке map_cache/,
поэтому при повторном запуске карта открывается мгновенно и работает без интернета
для уже просмотренных районов. Если интернета нет и тайлов в кэше нет, вместо
подложки показывается светлая сетка, а маркеры роутеров всё равно стоят на своих местах.
"""
import json
import math
import threading
import urllib.request
import webbrowser
from pathlib import Path

import flet as ft

BASE = Path(__file__).resolve().parent
CACHE = BASE / "map_cache"
TILE = 256
MIN_ZOOM, MAX_ZOOM = 10, 17
USER_AGENT = "KTelecom-Monitoring/1.0 (educational prototype)"
TILE_SOURCES = [
    "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
    "https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png",
]
STATUS_RU = {"OK": "Норма", "MEDIUM": "Предупреждение", "CRITICAL": "Критично"}


# ---------- Web Mercator ----------
def lonlat_to_px(lat, lon, z):
    n = TILE * 2 ** z
    x = (lon + 180.0) / 360.0 * n
    lat_r = math.radians(max(min(lat, 85.0511), -85.0511))
    y = (1 - math.log(math.tan(lat_r) + 1 / math.cos(lat_r)) / math.pi) / 2 * n
    return x, y


def px_to_lonlat(x, y, z):
    n = TILE * 2 ** z
    lon = x / n * 360.0 - 180.0
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    return lat, lon


def fit_zoom(points, width, height, margin=0.8):
    """Максимальный масштаб, при котором все роутеры помещаются в окно карты."""
    for z in range(MAX_ZOOM - 1, MIN_ZOOM - 1, -1):
        xs, ys = zip(*(lonlat_to_px(p["lat"], p["lon"], z) for p in points))
        if max(xs) - min(xs) <= width * margin and max(ys) - min(ys) <= height * margin:
            return z
    return MIN_ZOOM


# ---------- Загрузка тайлов ----------
def tile_path(z, x, y):
    return CACHE / str(z) / str(x) / f"{y}.png"


def download_tile(z, x, y):
    path = tile_path(z, x, y)
    if path.exists():
        return True
    for url in TILE_SOURCES:
        try:
            req = urllib.request.Request(url.format(z=z, x=x, y=y), headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=8) as resp:
                data = resp.read()
            if data[:4] == b"\x89PNG" or data[:3] == b"\xff\xd8\xff":
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
                return True
        except Exception:
            continue
    return False


class TileMap:
    """Интерактивная карта: перетаскивание мышью, колесо/кнопки для масштаба."""

    def __init__(self, page, classify, color, width=920, height=540):
        self.page = page
        self.classify = classify
        self.color = color
        self.W, self.H = width, height
        self.zoom = None
        self.cx = self.cy = 0.0          # центр карты в мировых пикселях текущего zoom
        self.points = {}
        self.tiles = {}                  # (z,x,y) -> ft.Image
        self.pending = set()
        self.failed = set()
        self.lock = threading.Lock()
        self.offline = False
        self.zones = []
        self.mass = set()
        self.center_point = (56.8389, 60.6057)

        self.tile_layer = ft.Stack(width=self.W, height=self.H)
        self.marker_layer = ft.Stack(width=self.W, height=self.H)
        self.status_text = ft.Text("", size=11, color="#77727A")
        self.zoom_text = ft.Text("", size=11, color="#625D65")
        self.gesture = ft.GestureDetector(
            content=ft.Stack([self.tile_layer, self.marker_layer], width=self.W, height=self.H),
            on_pan_update=self._on_pan,
            on_pan_end=lambda e: self.refresh(),
            on_scroll=self._on_scroll,
            drag_interval=20,
            mouse_cursor=ft.MouseCursor.MOVE,
        )
        self.view = ft.Container(
            content=self.gesture, width=self.W, height=self.H, bgcolor="#EEF0F2",
            border_radius=12, clip_behavior=ft.ClipBehavior.HARD_EDGE,
            border=ft.Border.all(1, "#E7E5E8"),
        )

    # ----- публичные методы -----
    def set_zones(self, clusters, mass=None):
        self.zones = clusters
        self.mass = mass or set()

    def set_points(self, latest):
        self.points = latest
        if self.zoom is None and latest:
            self.reset_view(update=False)
        if self.zoom is not None and not self.tile_layer.controls:
            self._draw_tiles()
        self._draw_markers()

    def reset_view(self, update=True):
        pts = list(self.points.values())
        if not pts:
            return
        self.zoom = fit_zoom(pts, self.W, self.H)
        lat = (min(p["lat"] for p in pts) + max(p["lat"] for p in pts)) / 2
        lon = (min(p["lon"] for p in pts) + max(p["lon"] for p in pts)) / 2
        self.cx, self.cy = lonlat_to_px(lat, lon, self.zoom)
        if update:
            self.refresh()

    def zoom_by(self, delta):
        nz = max(MIN_ZOOM, min(MAX_ZOOM, self.zoom + delta))
        if nz == self.zoom:
            return
        lat, lon = px_to_lonlat(self.cx, self.cy, self.zoom)
        self.zoom = nz
        self.cx, self.cy = lonlat_to_px(lat, lon, nz)
        self.refresh()

    def refresh(self):
        self._draw_tiles()
        self._draw_markers()
        self.page.update()

    # ----- внутренняя кухня -----
    def _origin(self):
        return self.cx - self.W / 2, self.cy - self.H / 2

    def _on_pan(self, e):
        d = e.local_delta
        self.cx -= d.x
        self.cy -= d.y
        ox, oy = self._origin()
        for (z, x, y), img in self.tiles.items():
            if z == self.zoom:
                img.left, img.top = x * TILE - ox, y * TILE - oy
        self._draw_markers()
        self.page.update()

    def _on_scroll(self, e):
        dy = getattr(e.scroll_delta, "y", 0) if getattr(e, "scroll_delta", None) else 0
        if dy:
            self.zoom_by(-1 if dy > 0 else 1)

    def _draw_tiles(self):
        z = self.zoom
        ox, oy = self._origin()
        n = 2 ** z
        x0, x1 = int(ox // TILE), int((ox + self.W) // TILE)
        y0, y1 = int(oy // TILE), int((oy + self.H) // TILE)
        controls, missing = [], []
        for tx in range(x0, x1 + 1):
            for ty in range(y0, y1 + 1):
                if not (0 <= tx < n and 0 <= ty < n):
                    continue
                key = (z, tx, ty)
                left, top = tx * TILE - ox, ty * TILE - oy
                img = self.tiles.get(key)
                if img is None and tile_path(z, tx, ty).exists():
                    img = ft.Image(src=tile_path(z, tx, ty).read_bytes(), width=TILE, height=TILE,
                                   fit=ft.BoxFit.FILL, gapless_playback=True)
                    self.tiles[key] = img
                if img is not None:
                    img.left, img.top = left, top
                    controls.append(img)
                else:
                    controls.append(self._placeholder(left, top))
                    if key not in self.failed:
                        missing.append(key)
        # выбрасываем из памяти тайлы других масштабов
        self.tiles = {k: v for k, v in self.tiles.items() if abs(k[0] - z) <= 1}
        self.tile_layer.controls = controls
        if missing:
            self._fetch(missing)
        self._update_status()

    def _placeholder(self, left, top):
        return ft.Container(left=left, top=top, width=TILE, height=TILE, bgcolor="#EEF0F2",
                            border=ft.Border.all(0.5, "#E1E3E6"))

    def _fetch(self, keys):
        with self.lock:
            keys = [k for k in keys if k not in self.pending]
            self.pending.update(keys)
        if not keys:
            return

        def worker():
            ok_any = False
            for key in keys:
                ok = download_tile(*key)
                with self.lock:
                    self.pending.discard(key)
                    if not ok:
                        self.failed.add(key)
                ok_any = ok_any or ok
            self.offline = not ok_any
            try:
                self._draw_tiles()
                self.page.update()
            except Exception:
                pass

        threading.Thread(target=worker, daemon=True).start()

    def _update_status(self):
        self.zoom_text.value = f"Масштаб: {self.zoom}"
        if self.pending:
            self.status_text.value = "Загрузка карты…"
        elif self.offline and self.failed:
            self.status_text.value = ("Нет доступа к серверу карт — подложка не загрузилась. "
                                      "Подключитесь к интернету и нажмите «Обновить карту».")
        else:
            self.status_text.value = "Перетаскивайте карту мышью, колесо мыши — масштаб."

    def _draw_markers(self):
        if self.zoom is None:
            return
        ox, oy = self._origin()
        markers = []
        # зоны скоплений / массовых нарушений
        for c in self.zones:
            px, py = lonlat_to_px(c["lat"], c["lon"], self.zoom)
            m_per_px = 156543.03392 * math.cos(math.radians(c["lat"])) / 2 ** self.zoom
            r = max(26, c["radius_km"] * 1000 / m_per_px)
            fill, line = ("#33D21F5B", "#D21F5B") if c["mass"] else ("#26B86B83", "#B86B83")
            markers.append(ft.Container(
                left=px - ox - r, top=py - oy - r, width=2 * r, height=2 * r, border_radius=r,
                bgcolor=fill, border=ft.Border.all(2, line),
                tooltip=("Зона массового нарушения" if c["mass"] else "Скопление проблемных устройств")
                        + f": {', '.join(c['routers'])}\nКритических: {c['critical']} · радиус {c['radius_km']:.1f} км",
            ))
        # диспетчерский центр
        px, py = lonlat_to_px(self.center_point[0], self.center_point[1], self.zoom)
        markers.append(ft.Container(
            left=px - ox - 9, top=py - oy - 9, width=18, height=18, bgcolor="#29272B", border_radius=3,
            border=ft.Border.all(2, "#FFFFFF"), tooltip="Диспетчерский центр К-Телеком",
            content=ft.Icon(ft.Icons.HOME_WORK, size=10, color="#FFFFFF"),
        ))
        for rid, x in sorted(self.points.items()):
            st = self.classify(x)
            px, py = lonlat_to_px(x["lat"], x["lon"], self.zoom)
            sx, sy = px - ox, py - oy
            if not (-40 < sx < self.W + 40 and -40 < sy < self.H + 40):
                continue
            tip = (f"{rid} · {STATUS_RU.get(st, st)}\n{x['location']}\nРайон: {x['district']}\n"
                   f"Ping {x['ping_ms']:.1f} мс · Download {x['download_mbps']:.1f} Мбит/с\n"
                   f"Upload {x['upload_mbps']:.1f} Мбит/с · Loss {x['packet_loss']:.1f}% · Jitter {x['jitter_ms']:.1f} мс")
            size = 22 if st == "CRITICAL" else 18
            markers.append(ft.Container(
                left=sx - size / 2, top=sy - size / 2, width=size, height=size,
                bgcolor=self.color(st), border_radius=size,
                border=ft.Border.all(3, "#FFFFFF"),
                shadow=ft.BoxShadow(blur_radius=6, color="#55000000", offset=ft.Offset(0, 1)),
                tooltip=tip,
            ))
            markers.append(ft.Container(
                left=sx + size / 2 + 2, top=sy - 9,
                content=ft.Text(rid, size=10, weight=ft.FontWeight.W_600, color="#29272B"),
                bgcolor="#E6FFFFFF", padding=ft.Padding(4, 1, 4, 1), border_radius=4,
            ))
        markers.append(ft.Container(
            right=4, bottom=4, bgcolor="#CCFFFFFF", padding=ft.Padding(5, 1, 5, 1), border_radius=4,
            content=ft.Text("© OpenStreetMap contributors", size=9, color="#625D65"),
        ))
        self.marker_layer.controls = markers


def export_browser_map(latest, classify, out_dir, clusters=(), center=(56.8389, 60.6057)):
    """Полноэкранная интерактивная карта Leaflet в браузере (резервный вариант)."""
    out_dir.mkdir(parents=True, exist_ok=True)
    pts = [{"id": rid, "lat": x["lat"], "lon": x["lon"], "district": x["district"],
            "status": classify(x), "address": x["location"],
            "ping": x["ping_ms"], "down": x["download_mbps"], "loss": x["packet_loss"]}
           for rid, x in sorted(latest.items())]
    html = """<!doctype html><html lang="ru"><head><meta charset="utf-8">
<title>К-Телеком · карта роутеров</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>html,body{margin:0;height:100%;font-family:Arial,sans-serif}#map{height:100%}
.legend{background:#fff;padding:8px 12px;border-radius:10px;box-shadow:0 2px 8px #0002;font-size:12px;line-height:20px}
.dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px}</style></head>
<body><div id="map"></div><script>
const p=__DATA__;const zones=__ZONES__;const center=__CENTER__;
const col={CRITICAL:'#D21F5B',MEDIUM:'#B86B83',OK:'#607889'};
const ru={CRITICAL:'Критично',MEDIUM:'Предупреждение',OK:'Норма'};
const m=L.map('map');
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(m);
const b=[];
p.forEach(x=>{b.push([x.lat,x.lon]);
 L.circleMarker([x.lat,x.lon],{color:'#fff',weight:3,fillColor:col[x.status],fillOpacity:1,radius:x.status==='CRITICAL'?11:9})
 .addTo(m).bindTooltip(x.id,{permanent:true,direction:'right',offset:[10,0]})
 .bindPopup('<b>'+x.id+'</b> · '+ru[x.status]+'<br>'+x.address+'<br>Район: '+x.district+'<br>Ping '+x.ping+' мс · Download '+x.down+' Мбит/с · Loss '+x.loss+'%');});
zones.forEach(z=>L.circle([z.lat,z.lon],{radius:z.r,color:z.mass?'#D21F5B':'#B86B83',fillOpacity:.18,weight:2}).addTo(m).bindPopup((z.mass?'Зона массового нарушения':'Скопление проблемных устройств')+': '+z.routers));
L.marker(center).addTo(m).bindTooltip('Диспетчерский центр');
m.fitBounds(b,{padding:[40,40]});
const lg=L.control({position:'bottomleft'});lg.onAdd=()=>{const d=L.DomUtil.create('div','legend');
d.innerHTML='<b>К-Телеком</b><br>'+Object.keys(col).reverse().map(k=>'<span class="dot" style="background:'+col[k]+'"></span>'+ru[k]).join('<br>');return d};lg.addTo(m);
</script></body></html>""".replace("__DATA__", json.dumps(pts, ensure_ascii=False))
    zones = [{"lat": c["lat"], "lon": c["lon"], "r": c["radius_km"] * 1000, "mass": c["mass"],
              "routers": ", ".join(c["routers"])} for c in clusters]
    html = html.replace("__ZONES__", json.dumps(zones, ensure_ascii=False)).replace("__CENTER__", json.dumps(list(center)))
    path = out_dir / "network_map.html"
    path.write_text(html, encoding="utf-8")
    webbrowser.open(path.as_uri())
    return str(path)
