"""Проверка входных телеметрических данных: обязательные поля, типы, временные метки,
отрицательные/некорректные и повторяющиеся значения."""
from datetime import datetime

REQUIRED = ("router_id", "location", "district", "lat", "lon", "timestamp",
            "ping_ms", "download_mbps", "upload_mbps", "packet_loss", "jitter_ms")
NUMERIC = ("lat", "lon", "ping_ms", "download_mbps", "upload_mbps", "packet_loss", "jitter_ms")


def validate(row, seen):
    """Возвращает список ошибок строки (пустой список — строка корректна)."""
    errors = []
    for k in REQUIRED:
        if k not in row or row[k] in ("", None):
            errors.append("Нет поля " + k)
    for k in NUMERIC:
        if row.get(k) in ("", None):
            continue
        try:
            v = float(row[k])
            if v < 0:
                errors.append("Отрицательное значение " + k)
        except (ValueError, TypeError):
            errors.append("Некорректное число " + k)
    try:
        if not (-90 <= float(row["lat"]) <= 90 and -180 <= float(row["lon"]) <= 180):
            errors.append("Координаты вне допустимого диапазона")
        if float(row["packet_loss"]) > 100:
            errors.append("Packet loss больше 100 %")
    except Exception:
        pass
    try:
        datetime.fromisoformat(row["timestamp"])
    except Exception:
        errors.append("Некорректная временная метка")
    key = (row.get("router_id"), row.get("timestamp"))
    if key in seen:
        errors.append("Повторяющееся измерение")
    seen.add(key)
    return errors
