"""Аналитическая подсистема: классификация, статистика, тенденции, пространственный анализ,
выявление массовых нарушений и поддержка принятия решений."""
from collections import defaultdict
from math import radians, sin, cos, asin, sqrt

# Диспетчерский центр (условно — центр Екатеринбурга)
CENTER = (56.8389, 60.6057)
METRICS = ("ping_ms", "download_mbps", "upload_mbps", "packet_loss", "jitter_ms")
METRIC_RU = {"ping_ms": "Ping, мс", "download_mbps": "Download, Мбит/с", "upload_mbps": "Upload, Мбит/с",
             "packet_loss": "Packet loss, %", "jitter_ms": "Jitter, мс"}
SEVERITY = {"OK": 0, "MEDIUM": 1, "CRITICAL": 2}
# Пороговые значения из кейса: (среднее отклонение, критическое отклонение, направление)
THRESHOLDS = {"ping_ms": (90, 200, "up"), "download_mbps": (50, 10, "down"), "upload_mbps": (10, 2, "down"),
              "packet_loss": (3, 10, "up"), "jitter_ms": (30, 60, "up")}
CLUSTER_RADIUS_KM = 2.5   # радиус поиска скоплений проблемных устройств
MA_WINDOW = 3             # окно скользящего среднего


# ---------- п.3: классификация ----------
def classify(x):
    if x["ping_ms"] > 200 or x["download_mbps"] < 10 or x["upload_mbps"] < 2 or x["packet_loss"] >= 10 or x["jitter_ms"] > 60:
        return "CRITICAL"
    if x["ping_ms"] > 90 or x["download_mbps"] < 50 or x["upload_mbps"] < 10 or x["packet_loss"] >= 3 or x["jitter_ms"] > 30:
        return "MEDIUM"
    return "OK"


def haversine_km(a, b, c, d):
    R = 6371
    p = radians(c - a); q = radians(d - b)
    z = sin(p / 2) ** 2 + cos(radians(a)) * cos(radians(c)) * sin(q / 2) ** 2
    return 2 * R * asin(sqrt(z))


def distance_to_center(x):
    return haversine_km(CENTER[0], CENTER[1], x["lat"], x["lon"])


# ---------- п.4: статистика за период ----------
def period_stats(items):
    """Среднее, минимум и максимум каждого показателя за выбранный период."""
    out = {}
    for m in METRICS:
        vals = [x[m] for x in items]
        out[m] = (sum(vals) / len(vals), min(vals), max(vals)) if vals else (0, 0, 0)
    return out


def moving_average(values, window=MA_WINDOW):
    """Скользящее среднее: для каждой точки — среднее по последним window значениям."""
    out = []
    for i in range(len(values)):
        part = values[max(0, i - window + 1):i + 1]
        out.append(sum(part) / len(part))
    return out


def state_durations(items, step_min=1):
    """Продолжительность нахождения роутера в каждом состоянии (в минутах)."""
    d = {"OK": 0, "MEDIUM": 0, "CRITICAL": 0}
    for x in items:
        d[classify(x)] += step_min
    return d


def current_streak(items):
    """Текущее состояние и сколько минут подряд оно длится; плюс длительность текущего нарушения."""
    if not items:
        return "OK", 0, 0
    st = classify(items[-1]); n = 0
    for x in reversed(items):
        if classify(x) != st:
            break
        n += 1
    problem = 0
    for x in reversed(items):
        if classify(x) == "OK":
            break
        problem += 1
    return st, n, problem


# ---------- п.5: устойчивое ухудшение и тенденции ----------
def sustained_degradation(items, k=3):
    """Устойчивое ухудшение: k последних измерений подряд не в норме
    и скользящее среднее степени тяжести не ниже MEDIUM."""
    if len(items) < k:
        return False
    sev = [SEVERITY[classify(x)] for x in items]
    return all(s >= 1 for s in sev[-k:]) and moving_average(sev)[-1] >= 1


def degradation_trend(items, points=5):
    """Тенденция ухудшения ДО достижения критических значений.
    Условия: скользящее среднее показателя последовательно ухудшается points измерений подряд,
    суммарное изменение не меньше 20 %, и показатель уже приблизился к порогу среднего отклонения
    (download/upload — не выше 1,6 порога, ping/jitter — не ниже 0,6 порога).
    Последнее измерение при этом ещё не критическое. Возвращает текст предупреждения или None."""
    if len(items) < points + MA_WINDOW - 1 or classify(items[-1]) == "CRITICAL":
        return None
    checks = [("download_mbps", "снижения скорости загрузки"), ("upload_mbps", "снижения скорости отдачи"),
              ("ping_ms", "роста задержки (ping)"), ("jitter_ms", "роста jitter")]
    for m, text in checks:
        med, _, direction = THRESHOLDS[m]
        ma = moving_average([x[m] for x in items])[-points:]
        steps = [ma[i + 1] - ma[i] for i in range(points - 1)]
        if direction == "down":
            ok = (all(st < 0 for st in steps) and (ma[0] - ma[-1]) / max(ma[0], 1e-6) >= 0.2
                  and ma[-1] <= med * 1.6)
        else:
            ok = (all(st > 0 for st in steps) and (ma[-1] - ma[0]) / max(ma[0], 1e-6) >= 0.2
                  and ma[-1] >= med * 0.6)
        if ok:
            return (f"Тенденция {text}: скользящее среднее ухудшается {points} измерений подряд "
                    f"(с {ma[0]:.1f} до {ma[-1]:.1f}), порог {med:g}")
    return None


def diagnose(history, latest, rid):
    """Система правил определения вероятной причины."""
    x = latest[rid]; district = x["district"]
    causes = []
    if x["ping_ms"] > 90 and x["packet_loss"] >= 3:
        causes.append("Проблемы с качеством канала связи: высокие ping и packet loss.")
    if x["jitter_ms"] > 30 and x["packet_loss"] >= 3:
        causes.append("Нестабильность соединения: высокие jitter и packet loss.")
    if x["download_mbps"] < 50 and x["ping_ms"] <= 90:
        causes.append("Ограничение пропускной способности или высокая нагрузка: низкий download при нормальном ping.")
    neighbours = [r for r, v in latest.items() if v["district"] == district and r != rid and classify(v) != "OK"]
    if classify(x) != "OK" and neighbours:
        causes.append(f"Одновременное ухудшение у нескольких роутеров района ({', '.join(neighbours)}): "
                      "возможна проблема сетевого оборудования или общего канала.")
    if not causes:
        causes.append("Показатели в норме или причина по текущим правилам не определена; продолжить наблюдение."
                      if classify(x) == "OK" else "Причина по текущим правилам не определена; продолжить наблюдение.")
    if sustained_degradation(history):
        causes.append("Зафиксировано устойчивое ухудшение (3 и более измерений подряд не в норме).")
    trend = degradation_trend(history)
    if trend:
        causes.append("Предупреждение: " + trend + ".")
    return "\n".join("• " + c for c in causes) + "\n\nПричина является предположительной и требует дополнительной проверки."


# ---------- п.4–6: районы, скопления, массовые нарушения ----------
def analyze_network(latest, histories=None):
    groups = defaultdict(list)
    for rid, x in latest.items():
        groups[x["district"]].append(x)
    out = []
    for district, items in groups.items():
        states = [classify(x) for x in items]
        problem = sum(s != "OK" for s in states); critical = states.count("CRITICAL")
        out.append({"district": district, "total": len(items), "problem": problem, "critical": critical,
                    "share": 100 * problem / len(items), "critical_share": 100 * critical / len(items),
                    "priority": "HIGH" if critical >= 2 else "MEDIUM" if problem else "LOW"})
    return sorted(out, key=lambda d: ({"HIGH": 0, "MEDIUM": 1, "LOW": 2}[d["priority"]], -d["critical_share"], -d["share"]))


def find_clusters(latest, radius_km=CLUSTER_RADIUS_KM):
    """Скопления проблемных устройств: проблемные роутеры, связанные цепочкой расстояний ≤ radius_km."""
    problem = [(rid, x) for rid, x in sorted(latest.items()) if classify(x) != "OK"]
    parent = {rid: rid for rid, _ in problem}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    for i in range(len(problem)):
        for j in range(i + 1, len(problem)):
            (r1, a), (r2, b) = problem[i], problem[j]
            if haversine_km(a["lat"], a["lon"], b["lat"], b["lon"]) <= radius_km:
                parent[find(r1)] = find(r2)
    groups = defaultdict(list)
    for rid, x in problem:
        groups[find(rid)].append((rid, x))
    clusters = []
    for members in groups.values():
        if len(members) < 2:
            continue
        lat = sum(x["lat"] for _, x in members) / len(members)
        lon = sum(x["lon"] for _, x in members) / len(members)
        critical = sum(classify(x) == "CRITICAL" for _, x in members)
        radius = max(haversine_km(lat, lon, x["lat"], x["lon"]) for _, x in members) + 0.4
        clusters.append({"routers": [r for r, _ in members], "lat": lat, "lon": lon, "radius_km": radius,
                         "critical": critical, "size": len(members),
                         "districts": sorted({x["district"] for _, x in members}),
                         "mass": critical >= 2,
                         "distance_km": haversine_km(CENTER[0], CENTER[1], lat, lon)})
    return sorted(clusters, key=lambda c: (-c["critical"], -c["size"]))


def mass_outages(latest, districts=None, clusters=None):
    """Алгоритм выявления массовых нарушений.
    Массовое нарушение = (а) скопление, где ≥2 критических устройств рядом, или
                         (б) район, где ≥2 критических устройств или ≥50 % устройств проблемные.
    Возвращает список событий и множество роутеров, затронутых массовым нарушением."""
    districts = districts if districts is not None else analyze_network(latest)
    clusters = clusters if clusters is not None else find_clusters(latest)
    events, affected = [], set()
    for c in clusters:
        if c["mass"]:
            events.append({"type": "Скопление", "where": ", ".join(c["districts"]), "routers": c["routers"],
                           "critical": c["critical"], "reason": f"{c['critical']} критических устройств в радиусе {c['radius_km']:.1f} км"})
            affected.update(c["routers"])
    for d in districts:
        if d["critical"] >= 2 or (d["share"] >= 50 and d["problem"] >= 2):
            routers = [r for r, x in sorted(latest.items()) if x["district"] == d["district"] and classify(x) != "OK"]
            same = next((e for e in events if e["type"] == "Скопление" and set(e["routers"]) == set(routers)), None)
            if same:   # то же самое нарушение уже найдено как скопление — объединяем
                same["type"] = "Район и скопление"
                same["reason"] += f"; в районе проблемных {d['problem']} из {d['total']} ({d['share']:.0f} %)"
                continue
            events.append({"type": "Район", "where": d["district"], "routers": routers, "critical": d["critical"],
                           "reason": f"проблемных {d['problem']} из {d['total']} ({d['share']:.0f} %), критических {d['critical']}"})
            affected.update(routers)
    return events, affected


def problems_by_distance(latest):
    """Проблемные адреса, отсортированные по расстоянию до диспетчерского центра."""
    rows = [(rid, x, classify(x), distance_to_center(x)) for rid, x in latest.items() if classify(x) != "OK"]
    return sorted(rows, key=lambda r: r[3])


# ---------- п.7: поддержка принятия решений ----------
def decision_support(latest, histories, districts=None):
    """Приоритизация действий с учётом критичности, числа затронутых устройств, длительности нарушения,
    территориального расположения и признаков массовой неисправности."""
    districts = districts if districts is not None else analyze_network(latest)
    clusters = find_clusters(latest)
    events, mass = mass_outages(latest, districts, clusters)
    cluster_of = {r: c for c in clusters for r in c["routers"]}
    district_problem = {d["district"]: d["problem"] for d in districts}
    out = []
    for rid, x in latest.items():
        h = list(histories[rid]); s = classify(x)
        _, _, duration = current_streak(h)
        sustained = sustained_degradation(h)
        trend = degradation_trend(h)
        dist = distance_to_center(x)
        is_mass = rid in mass
        affected = max(len(cluster_of[rid]["routers"]) if rid in cluster_of else 1,
                       district_problem.get(x["district"], 1) if is_mass else 1) if s != "OK" else 0
        critical_run = 0
        for v in reversed(h):
            if classify(v) != "CRITICAL":
                break
            critical_run += 1
        if s != "OK" and is_mass:
            rec, why = "Инициировать проверку сетевого оборудования района", "Есть признаки массовой неисправности"
        elif s == "CRITICAL" and critical_run >= 5:
            rec, why = "Рассмотреть необходимость выезда бригады", f"Критическое состояние {critical_run} мин подряд — не устраняется удалённо"
        elif s == "CRITICAL" and critical_run >= 3:
            rec, why = "Передать заявку техническому специалисту", "Подтверждённое критическое состояние (3+ измерения)"
        elif s == "CRITICAL" or sustained or trend:
            rec, why = "Провести удалённую диагностику", trend or ("Устойчивое ухудшение показателей" if sustained else "Однократное критическое измерение")
        elif s == "MEDIUM":
            rec, why = "Продолжить наблюдение", "Кратковременное или незначительное отклонение"
        else:
            rec, why = "Продолжить наблюдение", "Показатели в норме"
        # балл приоритета (чем больше — тем раньше реагировать)
        score = (SEVERITY[s] * 30 + min(duration, 10) * 3 + (25 if is_mass else 0)
                 + min(affected, 6) * 4 + (8 if trend else 0) + max(0.0, 10 - dist))
        if s == "OK" and not trend:
            score = 0
        out.append({"router_id": rid, "district": x["district"], "location": x["location"], "status": s,
                    "duration": duration, "affected": affected, "mass": is_mass, "distance_km": dist,
                    "score": round(score, 1), "recommendation": rec, "reason": why})
    return sorted(out, key=lambda r: (-r["score"], r["router_id"]))


def recommendations(latest, histories, districts=None):
    """Совместимость со старым интерфейсом: [(router_id, рекомендация)]."""
    return [(r["router_id"], r["recommendation"]) for r in decision_support(latest, histories, districts)]
