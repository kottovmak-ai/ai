import csv
import threading
import time
from collections import defaultdict, deque
from pathlib import Path

import flet as ft
import flet.canvas as cv

from analytics import (METRICS, METRIC_RU, THRESHOLDS, CENTER, classify, diagnose, analyze_network,
                       distance_to_center, period_stats, moving_average, state_durations, current_streak,
                       sustained_degradation, degradation_trend, find_clusters, mass_outages,
                       problems_by_distance, decision_support)
from data_validation import validate
from reporting import export_excel, open_file
from map_view import TileMap, export_browser_map

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
N = 10          # сколько последних измерений хранится для потокового анализа (п.9)
PRELOAD = 10    # сколько минут данных загружается при старте, остальное поступает потоком


def load():
    """Загрузка и проверка телеметрии. Возвращает корректные строки и список отклонённых."""
    result, rejected, seen = [], [], set()
    with open(DATA / "telemetry.csv", encoding="utf-8-sig") as f:
        for line_no, row in enumerate(csv.DictReader(f), start=2):
            errors = validate(row, seen)
            if errors:
                rejected.append({"line": line_no, "router_id": row.get("router_id") or "—",
                                 "timestamp": row.get("timestamp") or "—", "errors": "; ".join(errors)})
                continue
            for k in ("lat", "lon") + METRICS:
                row[k] = float(row[k])
            result.append(row)
    return result, rejected


def main(page: ft.Page):
    page.title = "К-Телеком | Мониторинг качества интернета"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.theme = ft.Theme(font_family="Arial", color_scheme_seed="#D21F5B")
    page.padding = 0
    page.bgcolor = "#F5F5F6"
    try:
        page.window.width = 1440
        page.window.height = 920
    except Exception:
        pass

    source, rejected = load()
    times = sorted({x["timestamp"] for x in source})
    by_time = defaultdict(list)
    for x in source:
        by_time[x["timestamp"]].append(x)

    history = defaultdict(lambda: deque(maxlen=N))   # последние N измерений (поток)
    full = defaultdict(list)                          # вся накопленная история (аналитика за период)
    latest, alerts, sent = {}, [], set()
    no_trend = defaultdict(int)
    state = {"index": 0, "running": False}

    PALETTE = {
        "accent": "#D21F5B", "accent_dark": "#B8184D", "accent_soft": "#FCEBF1",
        "background": "#F5F5F6", "surface": "#FFFFFF", "border": "#E7E5E8",
        "text": "#29272B", "muted": "#77727A", "subtle": "#A19BA3",
        "ok": "#607889", "medium": "#B86B83", "critical": "#D21F5B"
    }

    def color(s):
        return {"OK": PALETTE["ok"], "MEDIUM": PALETTE["medium"], "CRITICAL": PALETTE["critical"],
                "HIGH": PALETTE["critical"], "LOW": PALETTE["ok"]}.get(s, PALETTE["muted"])

    def hhmm(ts):
        return ts[11:16]

    # ---------------- элементы интерфейса ----------------
    title = ft.Text("Мониторинг качества интернет-соединения", size=25, weight=ft.FontWeight.W_600, color="#29272B")
    summary = ft.Row(wrap=True)
    quality_note = ft.Text(size=12, color="#77727A")
    status = ft.Dropdown(label="Статус", width=150, value="Все",
                         options=[ft.dropdown.Option(x) for x in ["Все", "OK", "MEDIUM", "CRITICAL"]])
    district = ft.Dropdown(label="Район", width=190, value="Все",
                           options=[ft.dropdown.Option("Все")] + [ft.dropdown.Option(x) for x in sorted({v["district"] for v in source})])
    search = ft.TextField(label="Адрес или ID", width=210)
    time_filter = ft.Dropdown(label="Время измерения", width=190, value="Текущее", options=[ft.dropdown.Option("Текущее")])

    def head(names):
        return [ft.DataColumn(ft.Text(x, color="#625D65", size=12, weight=ft.FontWeight.W_600)) for x in names]

    def tbl(names):
        return ft.DataTable(heading_row_height=44, data_row_min_height=44, columns=head(names), rows=[])

    table = tbl(["Роутер", "Район", "Время", "Ping", "Download", "Upload", "Loss", "Jitter", "До центра, км", "Статус"])
    districts_table = tbl(["Район", "Всего", "Проблемных", "Критических", "Доля проблемных", "Доля критических", "Приоритет"])
    distance_table = tbl(["Роутер", "Адрес", "Район", "Статус", "До центра, км"])
    decision_table = ft.DataTable(heading_row_height=44, data_row_min_height=40, data_row_max_height=64, column_spacing=22,
                                  columns=head(["#", "Роутер", "Район", "Статус", "Длит., мин", "Затронуто", "Массовая",
                                                "До центра, км", "Балл", "Рекомендация", "Обоснование"]), rows=[])
    mass_view = ft.Column(spacing=6)
    ids = sorted({x["router_id"] for x in source})
    pick = ft.Dropdown(label="Роутер", width=170, options=[ft.dropdown.Option(x) for x in ids], value=ids[0])
    period_from = ft.Dropdown(label="Период с", width=130)
    period_to = ft.Dropdown(label="по", width=130)
    metric_pick = ft.Dropdown(label="Показатель на графике", width=220, value="download_mbps",
                              options=[ft.dropdown.Option(key=m, text=METRIC_RU[m]) for m in METRICS])
    stats_table = tbl(["Показатель", "Среднее", "Минимум", "Максимум", "Скользящее среднее (посл.)"])
    durations_row = ft.Row(wrap=True, spacing=10)
    chart_box = ft.Container()
    history_table = tbl(["Время", "Ping", "Download", "Upload", "Loss", "Jitter", "Статус"])
    diagnosis = ft.Text(selectable=True, size=13, color="#29272B")
    alert_table = ft.DataTable(heading_row_height=44, data_row_min_height=44, data_row_max_height=64, columns=head(["Время", "Роутер", "Район", "Статус", "Сообщение"]), rows=[])
    stream_label = ft.Text("Поток остановлен")
    interval = ft.Dropdown(label="Интервал демонстрации", width=230, value="5 секунд",
                           options=[ft.dropdown.Option(x) for x in ["1 секунда", "5 секунд", "15 секунд", "60 секунд (как в ТЗ)"]])
    zones_view = ft.Column(spacing=4)

    def section(text):
        return ft.Text(text, size=18, weight=ft.FontWeight.W_600, color="#29272B")

    def hint(text):
        return ft.Text(text, size=12, color="#77727A")

    def card(label, val, col, width=185):
        return ft.Container(ft.Column([ft.Text(label, size=12, color="#817B83"),
                                       ft.Text(str(val), size=25, weight=ft.FontWeight.W_600, color=col)], spacing=5),
                            padding=18, width=width, bgcolor="#FFFFFF", border=ft.Border.all(1, "#E7E5E8"), border_radius=16,
                            shadow=ft.BoxShadow(blur_radius=10, color="#16000000", spread_radius=0, offset=ft.Offset(0, 2)))

    def white(content):
        return ft.Container(content, padding=18, bgcolor="#FFFFFF", border=ft.Border.all(1, "#E7E5E8"), border_radius=14)

    def status_cell(s):
        return ft.DataCell(ft.Text(s, color=color(s), weight=ft.FontWeight.BOLD))

    # ---------------- график динамики (п.7) ----------------
    def build_chart(items, metric):
        W, H, L, R, T, B = 820, 250, 52, 16, 16, 34
        if len(items) < 2:
            return ft.Text("Недостаточно измерений для графика.", color="#77727A")
        vals = [x[metric] for x in items]
        ma = moving_average(vals)
        med, crit, _ = THRESHOLDS[metric]
        hi = max(vals + [med, crit]) * 1.1
        lo = 0
        def X(i): return L + (W - L - R) * i / (len(vals) - 1)
        def Y(v): return T + (H - T - B) * (1 - (v - lo) / (hi - lo or 1))
        shapes = []
        for k in range(5):
            v = lo + (hi - lo) * k / 4
            shapes.append(cv.Line(L, Y(v), W - R, Y(v), paint=ft.Paint(color="#EEECEF", stroke_width=1)))
            shapes.append(cv.Text(4, Y(v) - 7, f"{v:.0f}", style=ft.TextStyle(size=10, color="#8D858D")))
        for v, c, name in ((med, PALETTE["medium"], "среднее откл."), (crit, PALETTE["critical"], "критическое")):
            shapes.append(cv.Line(L, Y(v), W - R, Y(v), paint=ft.Paint(color=c, stroke_width=1.2, stroke_dash_pattern=[6, 4])))
            shapes.append(cv.Text(W - R - 110, Y(v) - 15, f"{name}: {v:g}", style=ft.TextStyle(size=10, color=c)))
        def path(series, col, width):
            el = [cv.Path.MoveTo(X(0), Y(series[0]))] + [cv.Path.LineTo(X(i), Y(v)) for i, v in enumerate(series)]
            return cv.Path(el, paint=ft.Paint(color=col, stroke_width=width, style=ft.PaintingStyle.STROKE))
        shapes.append(path(vals, "#A9B8C3", 2))
        shapes.append(path(ma, PALETTE["accent"], 3))
        for i, x in enumerate(items):
            shapes.append(cv.Circle(X(i), Y(vals[i]), 4, paint=ft.Paint(color=color(classify(x)))))
        step = max(1, len(items) // 10)
        for i in range(0, len(items), step):
            shapes.append(cv.Text(X(i) - 14, H - B + 8, hhmm(items[i]["timestamp"]), style=ft.TextStyle(size=10, color="#8D858D")))
        legend = ft.Row([
            ft.Row([ft.Container(width=16, height=3, bgcolor="#A9B8C3"), ft.Text("Измерения", size=11, color="#625D65")], spacing=5),
            ft.Row([ft.Container(width=16, height=3, bgcolor=PALETTE["accent"]), ft.Text(f"Скользящее среднее (окно 3)", size=11, color="#625D65")], spacing=5),
            ft.Text("Точки окрашены по статусу измерения", size=11, color="#8D858D"),
        ], spacing=18, wrap=True)
        return ft.Column([ft.Text(f"Динамика: {METRIC_RU[metric]}", size=15, weight=ft.FontWeight.W_600, color="#29272B"),
                          legend, ft.Container(cv.Canvas(shapes, width=W, height=H), width=W, height=H)], spacing=8)

    # ---------------- карта ----------------
    tile_map = TileMap(page, classify, color)

    # ---------------- отрисовка ----------------
    def processed_times():
        return times[:state["index"]]

    def render():
        pts = processed_times()
        states = {k: classify(v) for k, v in latest.items()}
        counts = {s: list(states.values()).count(s) for s in ("OK", "MEDIUM", "CRITICAL")}
        ds = analyze_network(latest)
        clusters = find_clusters(latest)
        events, mass = mass_outages(latest, ds, clusters)

        summary.controls = [
            card("Всего роутеров", len(latest), PALETTE["text"]),
            card("В норме", counts["OK"], PALETTE["ok"]),
            card("Предупреждения", counts["MEDIUM"], PALETTE["medium"]),
            card("Критические", counts["CRITICAL"], PALETTE["critical"]),
            card("Оповещения", len(alerts), PALETTE["muted"]),
            card("Массовые нарушения", len(events), PALETTE["critical"] if events else PALETTE["muted"]),
        ]
        quality_note.value = (f"Проверка данных: принято {len(source)} измерений, отклонено {len(rejected)} "
                              f"(пропуски, отрицательные и некорректные значения, неверные метки времени, повторы). "
                              f"Обработано минут: {len(pts)} из {len(times)}.")

        # фильтр по времени
        opts = ["Текущее"] + [hhmm(t) for t in pts]
        if [o.key or o.text for o in time_filter.options] != opts:
            time_filter.options = [ft.dropdown.Option(o) for o in opts]
            if time_filter.value not in opts:
                time_filter.value = "Текущее"
        if time_filter.value == "Текущее":
            snapshot = latest
        else:
            ts = next((t for t in pts if hhmm(t) == time_filter.value), None)
            snapshot = {x["router_id"]: x for x in by_time.get(ts, [])}

        table.rows = []
        for rid, x in sorted(snapshot.items()):
            s = classify(x)
            if status.value != "Все" and status.value != s: continue
            if district.value != "Все" and district.value != x["district"]: continue
            if search.value and search.value.lower() not in (rid + x["location"]).lower(): continue
            vals = [rid, x["district"], hhmm(x["timestamp"]), f'{x["ping_ms"]:.1f}', f'{x["download_mbps"]:.1f}',
                    f'{x["upload_mbps"]:.1f}', f'{x["packet_loss"]:.1f}%', f'{x["jitter_ms"]:.1f}', f'{distance_to_center(x):.2f}']
            table.rows.append(ft.DataRow(cells=[ft.DataCell(ft.Text(v)) for v in vals] + [status_cell(s)]))

        # аналитика районов
        districts_table.rows = [ft.DataRow(cells=[ft.DataCell(ft.Text(str(v))) for v in
                                                  [d["district"], d["total"], d["problem"], d["critical"],
                                                   f'{d["share"]:.0f}%', f'{d["critical_share"]:.0f}%']] + [status_cell(d["priority"])])
                                for d in ds]
        mass_view.controls = []
        for ev in events:
            mass_view.controls.append(ft.Container(
                ft.Text(f'{ev["type"]}: {ev["where"]} — {ev["reason"]}. Устройства: {", ".join(ev["routers"])}',
                        size=13, color="#29272B"), padding=10, bgcolor="#FCEBF1", border_radius=10))
        for c in clusters:
            if not c["mass"]:
                mass_view.controls.append(ft.Container(
                    ft.Text(f'Скопление проблемных устройств ({", ".join(c["districts"])}): {", ".join(c["routers"])} '
                            f'— радиус {c["radius_km"]:.1f} км, критических {c["critical"]}', size=13, color="#29272B"),
                    padding=10, bgcolor="#F5F5F6", border_radius=10))
        if not mass_view.controls:
            mass_view.controls = [hint("Массовых нарушений и скоплений проблемных устройств не обнаружено.")]

        distance_table.rows = [ft.DataRow(cells=[ft.DataCell(ft.Text(rid)), ft.DataCell(ft.Text(x["location"])),
                                                 ft.DataCell(ft.Text(x["district"])), status_cell(s),
                                                 ft.DataCell(ft.Text(f"{d:.2f}"))])
                               for rid, x, s, d in problems_by_distance(latest)]
        if not distance_table.rows:
            distance_table.rows = [ft.DataRow(cells=[ft.DataCell(ft.Text("—")), ft.DataCell(ft.Text("Проблемных адресов нет"))]
                                   + [ft.DataCell(ft.Text("—"))] * 3)]

        decision_table.rows = []
        for i, r in enumerate(decision_support(latest, history, ds), 1):
            decision_table.rows.append(ft.DataRow(cells=[
                ft.DataCell(ft.Text(str(i))), ft.DataCell(ft.Text(r["router_id"])), ft.DataCell(ft.Text(r["district"])),
                status_cell(r["status"]), ft.DataCell(ft.Text(str(r["duration"]))), ft.DataCell(ft.Text(str(r["affected"]))),
                ft.DataCell(ft.Text("Да" if r["mass"] else "Нет", color=PALETTE["critical"] if r["mass"] else None)),
                ft.DataCell(ft.Text(f'{r["distance_km"]:.2f}')), ft.DataCell(ft.Text(f'{r["score"]:.0f}', weight=ft.FontWeight.BOLD)),
                ft.DataCell(ft.Text(r["recommendation"], width=230)), ft.DataCell(ft.Text(r["reason"], size=12, color="#77727A", width=260)),
            ]))

        # диагностика
        render_diagnostics(pts)

        # оповещения
        alert_table.rows = [ft.DataRow(cells=[ft.DataCell(ft.Text(hhmm(a["time"]))), ft.DataCell(ft.Text(a["router_id"])),
                                              ft.DataCell(ft.Text(a["district"])), status_cell(a["status"]),
                                              ft.DataCell(ft.Text(a["message"], width=470))]) for a in alerts[::-1]]
        if not alert_table.rows:
            alert_table.rows = [ft.DataRow(cells=[ft.DataCell(ft.Text("—"))] * 4 + [ft.DataCell(ft.Text("Оповещений пока нет."))])]

        # карта
        tile_map.set_zones(clusters, mass)
        tile_map.set_points(latest)
        zones_view.controls = [hint(f"Зона: {', '.join(c['routers'])} · {', '.join(c['districts'])} · "
                                    f"{'массовое нарушение' if c['mass'] else 'скопление проблемных устройств'} · "
                                    f"{c['distance_km']:.1f} км от диспетчерского центра") for c in clusters] \
            or [hint("Зон массовых нарушений не обнаружено.")]
        page.update()

    def render_diagnostics(pts):
        rid = pick.value
        opts = [hhmm(t) for t in pts]
        if [o.key or o.text for o in period_from.options] != opts:
            period_from.options = [ft.dropdown.Option(o) for o in opts]
            period_to.options = [ft.dropdown.Option(o) for o in opts]
        if period_from.value not in opts:
            period_from.value = opts[0] if opts else None
        if period_to.value not in opts or state["running"]:
            period_to.value = opts[-1] if opts else None
        items = [x for x in full[rid] if period_from.value and period_to.value
                 and period_from.value <= hhmm(x["timestamp"]) <= period_to.value]
        st = period_stats(items)
        stats_table.rows = []
        for m in METRICS:
            ma = moving_average([x[m] for x in items])
            avg, mn, mx = st[m]
            stats_table.rows.append(ft.DataRow(cells=[ft.DataCell(ft.Text(METRIC_RU[m]))] +
                                    [ft.DataCell(ft.Text(f"{v:.1f}")) for v in (avg, mn, mx, ma[-1] if ma else 0)]))
        dur = state_durations(items)
        cur, run, problem = current_streak(full[rid])
        durations_row.controls = [
            card("В норме, мин", dur["OK"], PALETTE["ok"], 170),
            card("Предупреждение, мин", dur["MEDIUM"], PALETTE["medium"], 170),
            card("Критично, мин", dur["CRITICAL"], PALETTE["critical"], 170),
            card(f"Сейчас {cur}, мин подряд", run, color(cur), 190),
        ]
        chart_box.content = build_chart(items, metric_pick.value)
        h = list(history[rid])
        history_table.rows = [ft.DataRow(cells=[ft.DataCell(ft.Text(v)) for v in
                                                [hhmm(x["timestamp"]), f'{x["ping_ms"]:.1f}', f'{x["download_mbps"]:.1f}',
                                                 f'{x["upload_mbps"]:.1f}', f'{x["packet_loss"]:.1f}%', f'{x["jitter_ms"]:.1f}']]
                                        + [status_cell(classify(x))]) for x in h[::-1]]
        diagnosis.value = diagnose(h, latest, rid) if rid in latest else ""

    # ---------------- поток и оповещения (п.5) ----------------
    def add_alert(x, st, msg):
        alerts.append({"time": x["timestamp"], "router_id": x["router_id"], "district": x["district"], "status": st, "message": msg})

    def ingest(x):
        rid = x["router_id"]
        history[rid].append(x); full[rid].append(x); latest[rid] = x
        h = list(history[rid])
        cur, run, _ = current_streak(h)
        if cur == "OK" and run >= 3:
            # неисправность устранена (3 измерения подряд в норме) — следующая неисправность снова даст оповещение
            for k in (rid + ":crit", rid + ":sust"):
                sent.discard(k)
        if len(h) >= 3 and all(classify(v) == "CRITICAL" for v in h[-3:]) and rid + ":crit" not in sent:
            add_alert(x, "CRITICAL", "Три последовательных критических измерения"); sent.add(rid + ":crit")
        elif sustained_degradation(h) and rid + ":sust" not in sent and rid + ":crit" not in sent:
            add_alert(x, "MEDIUM", "Устойчивое ухудшение качества соединения (3 измерения подряд не в норме)"); sent.add(rid + ":sust")
        trend = degradation_trend(h)
        no_trend[rid] = 0 if trend else no_trend[rid] + 1
        if no_trend[rid] >= 3:   # тенденция прекратилась — можно снова предупреждать
            sent.discard(rid + ":trend")
        if trend and rid + ":trend" not in sent:
            add_alert(x, "MEDIUM", trend); sent.add(rid + ":trend")

    def check_mass(ts):
        events, _ = mass_outages(latest)
        active = set()
        for ev in events:
            key = "mass:" + ev["type"] + ":" + ev["where"]
            active.add(key)
            if key not in sent:
                alerts.append({"time": ts, "router_id": ", ".join(ev["routers"]), "district": ev["where"], "status": "CRITICAL",
                               "message": f"Массовое нарушение ({ev['type'].lower()}): {ev['reason']}"})
                sent.add(key)
        for k in [k for k in sent if k.startswith("mass:") and k not in active]:
            sent.discard(k)

    def step():
        """Обработка следующего пакета измерений (одна минута)."""
        if state["index"] >= len(times):
            return False
        ts = times[state["index"]]
        for x in by_time[ts]:
            ingest(x)
        check_mass(ts)
        state["index"] += 1
        return True

    def reset_data():
        history.clear(); full.clear(); latest.clear(); alerts.clear(); sent.clear(); no_trend.clear()
        state["index"] = 0
        for _ in range(min(PRELOAD, len(times))):
            step()

    def tick():
        if not step():
            state["running"] = False
            stream_label.value = "Все измерения из файла обработаны. Нажмите «Сначала», чтобы повторить демонстрацию."
            render(); return
        stream_label.value = f"Поток активен · обработано минут: {state['index']} из {len(times)} · последнее измерение {hhmm(times[state['index'] - 1])}"
        render()

    def start(e):
        if state["running"]:
            return
        state["running"] = True
        def loop():
            while state["running"]:
                tick()
                delay = {"1 секунда": 1, "5 секунд": 5, "15 секунд": 15}.get(interval.value, 60)
                for _ in range(delay * 10):
                    if not state["running"]:
                        break
                    time.sleep(0.1)
        threading.Thread(target=loop, daemon=True).start()

    def stop(e):
        state["running"] = False
        stream_label.value = f"Поток остановлен · обработано минут: {state['index']} из {len(times)}"
        page.update()

    def restart(e):
        state["running"] = False
        time.sleep(0.15)
        reset_data()
        stream_label.value = f"Данные сброшены · обработано минут: {state['index']} из {len(times)}"
        render()

    # ---------------- уведомления, Excel, карта ----------------
    def notify(text):
        bar = ft.SnackBar(ft.Text(text), duration=6000)
        try:
            page.show_dialog(bar)
        except Exception:
            page.snack_bar = bar; bar.open = True; page.update()

    def export(e):
        try:
            path = export_excel(latest, history, alerts, full=full, rejected=rejected)
            notify("Excel-отчёт сохранён: " + path)
            open_file(path)
        except PermissionError:
            notify("Не удалось сохранить Excel: файл открыт в другой программе. Закройте его и повторите.")
        except Exception as exc:
            notify(f"Не удалось создать Excel: {exc}")

    def build_map_panel():
        legend = ft.Row([
            ft.Row([ft.Container(width=10, height=10, bgcolor=color(st), border_radius=8), ft.Text(label, size=11, color="#625D65")], spacing=5)
            for st, label in [("OK", "Норма"), ("MEDIUM", "Предупреждение"), ("CRITICAL", "Критично")]
        ] + [ft.Row([ft.Container(width=12, height=12, bgcolor="#33D21F5B", border=ft.Border.all(1.5, "#D21F5B"), border_radius=8),
                     ft.Text("Зона массового нарушения", size=11, color="#625D65")], spacing=5),
             ft.Row([ft.Container(width=10, height=10, bgcolor="#29272B", border_radius=2),
                     ft.Text("Диспетчерский центр", size=11, color="#625D65")], spacing=5)],
            wrap=True, spacing=18)
        controls = ft.Row([
            ft.IconButton(ft.Icons.ADD, tooltip="Приблизить", on_click=lambda e: tile_map.zoom_by(1)),
            ft.IconButton(ft.Icons.REMOVE, tooltip="Отдалить", on_click=lambda e: tile_map.zoom_by(-1)),
            ft.IconButton(ft.Icons.CENTER_FOCUS_STRONG, tooltip="Показать все роутеры", on_click=lambda e: tile_map.reset_view()),
            tile_map.zoom_text,
        ], spacing=2)
        return ft.Container(
            content=ft.Column([
                ft.Text("Карта размещения роутеров · Екатеринбург", size=17, weight=ft.FontWeight.W_600, color="#29272B"),
                ft.Text("Карта местности OpenStreetMap. Наведите курсор на маркер, чтобы увидеть адрес, статус и показатели.", size=11, color="#77727A"),
                ft.Row([legend, ft.Container(expand=True), controls], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                tile_map.view,
                tile_map.status_text,
                zones_view,
            ], spacing=10),
            padding=18, bgcolor="#FFFFFF", border=ft.Border.all(1, "#E7E5E8"), border_radius=14
        )

    map_panel = build_map_panel()

    def make_map(e):
        tile_map.failed.clear()
        render(); tile_map.refresh()
        notify("Карта обновлена.")

    def open_browser_map(e):
        try:
            path = export_browser_map(latest, classify, BASE / "reports", find_clusters(latest), CENTER)
            notify("Интерактивная карта открыта в браузере: " + path)
        except Exception as exc:
            notify(f"Не удалось открыть карту: {exc}")

    for c in (status, district, time_filter, pick, period_from, period_to, metric_pick):
        c.on_select = lambda e: render()
    search.on_change = lambda e: render()

    def scroll_x(control):
        return ft.Row([control], scroll=ft.ScrollMode.AUTO)

    panels = {
        "Обзор": ft.Column([summary, quality_note, ft.Row([status, district, search, time_filter], wrap=True), scroll_x(table)],
                           scroll=ft.ScrollMode.AUTO, spacing=14),
        "Аналитика и решения": ft.Column([
            section("Статистика по районам и территориальные приоритеты"), white(scroll_x(districts_table)),
            section("Массовые нарушения и скопления проблемных устройств"),
            hint("Массовое нарушение: ≥2 критических устройств в одном районе или в радиусе 2,5 км, либо ≥50 % проблемных устройств района."),
            mass_view,
            section("Проблемные адреса по расстоянию до диспетчерского центра"), white(scroll_x(distance_table)),
            section("Рекомендации специалистам (по приоритету)"),
            hint("Балл приоритета учитывает критичность, длительность нарушения, число затронутых устройств, "
                 "признаки массовой неисправности и удалённость от диспетчерского центра."),
            white(scroll_x(decision_table)),
        ], scroll=ft.ScrollMode.AUTO, spacing=14),
        "Диагностика": ft.Column([
            ft.Row([pick, period_from, period_to, metric_pick], wrap=True),
            section("Статистика за выбранный период"), white(scroll_x(stats_table)),
            section("Продолжительность нахождения в каждом состоянии"), durations_row,
            white(chart_box),
            section("Вероятная причина"), white(diagnosis),
            section(f"Последние {N} измерений"), white(scroll_x(history_table)),
        ], scroll=ft.ScrollMode.AUTO, spacing=14),
        "Поток и оповещения": ft.Column([
            ft.Row([interval, ft.Button("Запустить", on_click=start), ft.Button("Остановить", on_click=stop),
                    ft.Button("Сначала", on_click=restart)], wrap=True),
            stream_label,
            hint("Имитация поступления измерений: один пакет = одна минута. Повторные оповещения по одной неисправности "
                 "не формируются, пока роутер не вернётся в норму."),
            section("История оповещений"), white(scroll_x(alert_table)),
        ], scroll=ft.ScrollMode.AUTO, spacing=14),
        "Карта и Excel": ft.Column([
            ft.Row([ft.Button("Обновить карту", on_click=make_map), ft.Button("Открыть карту в браузере", on_click=open_browser_map),
                    ft.Button("Выгрузить в Excel (.xlsx)", on_click=export)], wrap=True),
            map_panel,
        ], scroll=ft.ScrollMode.AUTO),
    }
    panel = ft.Container(content=panels["Обзор"], expand=True, padding=22, bgcolor="#F5F5F6", border_radius=16)
    nav_items = []

    def show_panel(name):
        panel.content = panels[name]
        for item_name, item in zip(panels.keys(), nav_items):
            item.bgcolor = "#FCEBF1" if item_name == name else "#FFFFFF"
        page.update()

    for name in panels:
        nav_items.append(
            ft.Container(
                content=ft.Text(name, size=14, color="#454148", weight=ft.FontWeight.W_600),
                padding=ft.Padding(16, 14, 12, 14),
                bgcolor="#FCEBF1" if name == "Обзор" else "#FFFFFF",
                border_radius=12,
                on_click=lambda e, n=name: show_panel(n),
                ink=True
            )
        )

    sidebar = ft.Container(
        width=245,
        bgcolor="#FFFFFF",
        border=ft.Border.only(right=ft.BorderSide(1, "#E7E5E8")),
        padding=18,
        content=ft.Column(
            [
                ft.Container(
                    content=ft.Column([
                        ft.Image(src=(BASE / "logo_k_telecom.jpeg").read_bytes(), width=205, height=62, fit=ft.BoxFit.CONTAIN),
                        ft.Text("МОНИТОРИНГ СЕТИ", size=10, color="#D21F5B", weight=ft.FontWeight.BOLD)
                    ], spacing=5),
                    padding=ft.Padding(6, 12, 6, 24)
                ),
                ft.Text("РАБОЧЕЕ ПРОСТРАНСТВО", size=10, color="#8D858D", weight=ft.FontWeight.BOLD),
                *nav_items,
                ft.Container(expand=True),
                ft.Container(
                    content=ft.Column([
                        ft.Text("СИСТЕМА МОНИТОРИНГА", size=10, color="#8D858D", weight=ft.FontWeight.BOLD),
                        ft.Text("Учебный прототип\nСинтетические данные\n\nВыполнила: Никлюдова Маргарита\nФТ, 160007", size=11, color="#77727A")
                    ], spacing=5),
                    padding=12,
                    bgcolor="#FCEBF1",
                    border_radius=10
                )
            ],
            expand=True,
            spacing=10
        )
    )

    workspace = ft.Column([
        ft.Container(
            content=ft.Row([
                ft.Column([
                    title,
                    ft.Text("Состояние сети • Екатеринбург и УрФО", size=13, color="#77727A")
                ], spacing=4),
                ft.Container(expand=True),
                ft.Container(
                    content=ft.Row([
                        ft.Container(width=8, height=8, bgcolor="#D21F5B", border_radius=10),
                        ft.Text("Демо-режим", size=12, color="#77727A")
                    ], spacing=8),
                    padding=ft.Padding(12, 8, 12, 8),
                    bgcolor="#FCEBF1",
                    border_radius=20
                )
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            padding=ft.Padding(30, 24, 30, 20),
            bgcolor="#FFFFFF",
            border=ft.Border.only(bottom=ft.BorderSide(1, "#E7E5E8"))
        ),
        panel
    ], expand=True, spacing=0)

    page.add(ft.Row([sidebar, workspace], expand=True, spacing=0, vertical_alignment=ft.CrossAxisAlignment.STRETCH))
    reset_data()
    stream_label.value = f"Поток остановлен · загружено минут: {state['index']} из {len(times)}"
    render()


ft.run(main)
