import flet as ft, csv, threading, time
from pathlib import Path
from collections import defaultdict,deque
from analytics import classify,diagnose,analyze_network,haversine_km,recommendations
from data_validation import validate
from reporting import export_excel, open_file
from map_view import TileMap, export_browser_map

BASE=Path(__file__).resolve().parent; DATA=BASE/"data"; CENTER=(56.8389,60.6057); N=10
METRICS=("ping_ms","download_mbps","upload_mbps","packet_loss","jitter_ms")
def load():
    result=[]; seen=set()
    with open(DATA/"telemetry.csv",encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            if validate(row,seen): continue
            for k in ("lat","lon")+METRICS: row[k]=float(row[k])
            result.append(row)
    return result

def main(page:ft.Page):
    page.title="К-Телеком | Мониторинг качества интернета"; page.theme_mode=ft.ThemeMode.LIGHT
    page.theme=ft.Theme(font_family="Arial", color_scheme_seed="#D21F5B")
    page.padding=0; page.bgcolor="#F5F5F6"
    try:
        page.window.width=1440; page.window.height=920
    except Exception:
        pass
    source=load(); history=defaultdict(lambda:deque(maxlen=N)); latest={}; alerts=[]; sent=set()
    for x in source: history[x["router_id"]].append(x); latest[x["router_id"]]=x
    index=0; running=False
    ids=sorted(latest)
    title=ft.Text("Мониторинг качества интернет-соединения",size=25,weight=ft.FontWeight.W_600,color="#29272B")
    summary=ft.Row(wrap=True)
    status=ft.Dropdown(label="Статус",width=150,value="Все",options=[ft.dropdown.Option(x) for x in ["Все","OK","MEDIUM","CRITICAL"]])
    district=ft.Dropdown(label="Район",width=190,value="Все",options=[ft.dropdown.Option("Все")]+[ft.dropdown.Option(x) for x in sorted({v["district"] for v in latest.values()})])
    search=ft.TextField(label="Адрес или ID",width=210)
    table=ft.DataTable(heading_row_height=44, data_row_min_height=44, columns=[ft.DataColumn(ft.Text(x, color="#625D65", size=12, weight=ft.FontWeight.W_600)) for x in ["Роутер","Район","Ping","Download","Upload","Loss","Jitter","Статус"]],rows=[])
    districts_table=ft.DataTable(heading_row_height=44, data_row_min_height=44, columns=[ft.DataColumn(ft.Text(x, color="#625D65", size=12, weight=ft.FontWeight.W_600)) for x in ["Район","Всего","Проблемных","Критических","Доля","Приоритет"]],rows=[])
    pick=ft.Dropdown(label="Роутер",width=220,options=[ft.dropdown.Option(x) for x in ids],value=ids[0])
    history_view=ft.Column(); diagnosis=ft.Text(selectable=True)
    alert_view=ft.Column(); advice=ft.Column()
    stream_label=ft.Text("Поток остановлен"); interval=ft.Dropdown(label="Интервал демонстрации",width=180,value="5 секунд",options=[ft.dropdown.Option(x) for x in ["5 секунд","15 секунд","60 секунд"]])
    PALETTE = {
        "accent": "#D21F5B", "accent_dark": "#B8184D", "accent_soft": "#FCEBF1",
        "background": "#F5F5F6", "surface": "#FFFFFF", "border": "#E7E5E8",
        "text": "#29272B", "muted": "#77727A", "subtle": "#A19BA3",
        "ok": "#607889", "medium": "#B86B83", "critical": "#D21F5B"
    }
    def color(s):
        return {"OK":PALETTE["ok"],"MEDIUM":PALETTE["medium"],"CRITICAL":PALETTE["critical"]}.get(s,PALETTE["muted"])
    def card(label,val,col):
        return ft.Container(ft.Column([ft.Text(label,size=12,color="#817B83"),ft.Text(str(val),size=25,weight=ft.FontWeight.W_600,color=col)],spacing=5),padding=18,width=185,bgcolor="#FFFFFF",border=ft.Border.all(1,"#E7E5E8"),border_radius=16,shadow=ft.BoxShadow(blur_radius=10,color="#16000000",spread_radius=0,offset=ft.Offset(0,2)))
    def render():
        states={k:classify(v) for k,v in latest.items()}; counts={s:list(states.values()).count(s) for s in ("OK","MEDIUM","CRITICAL")}
        summary.controls=[
            card("Всего роутеров",len(latest),PALETTE["text"]),
            card("В норме",counts["OK"],PALETTE["ok"]),
            card("Предупреждения",counts["MEDIUM"],PALETTE["medium"]),
            card("Критические",counts["CRITICAL"],PALETTE["critical"]),
            card("Оповещения",len(alerts),PALETTE["muted"])
        ]
        table.rows=[]
        for rid,x in sorted(latest.items()):
            s=states[rid]
            if status.value!="Все" and status.value!=s: continue
            if district.value!="Все" and district.value!=x["district"]: continue
            if search.value and search.value.lower() not in (rid+x["location"]).lower(): continue
            vals=[rid,x["district"],f'{x["ping_ms"]:.1f}',f'{x["download_mbps"]:.1f}',f'{x["upload_mbps"]:.1f}',f'{x["packet_loss"]:.1f}%',f'{x["jitter_ms"]:.1f}']
            table.rows.append(ft.DataRow(cells=[ft.DataCell(ft.Text(v)) for v in vals]+[ft.DataCell(ft.Text(s,color=color(s),weight=ft.FontWeight.BOLD))]))
        ds=analyze_network(latest,history); districts_table.rows=[]
        for d in ds:
            districts_table.rows.append(ft.DataRow(cells=[ft.DataCell(ft.Text(str(v))) for v in [d["district"],d["total"],d["problem"],d["critical"],f'{d["share"]:.0f}%',d["priority"]]]))
        alert_view.controls=[ft.Text(f'{a["time"]} · {a["router_id"]} · {a["district"]} · {a["message"]}') for a in alerts[-40:][::-1]] or [ft.Text("Оповещений пока нет.")]
        tile_map.set_points(latest)
        h=list(history[pick.value]); history_view.controls=[ft.Text("Последние измерения: время | ping | download | loss | jitter",weight=ft.FontWeight.BOLD)]+[ft.Text(f'{x["timestamp"][11:19]} | {x["ping_ms"]:.1f} | {x["download_mbps"]:.1f} | {x["packet_loss"]:.1f} | {x["jitter_ms"]:.1f}') for x in h]
        diagnosis.value=diagnose(h,latest,pick.value)
        advice.controls=[ft.Text(f"{rid}: {rec}",size=13) for rid,rec in recommendations(latest,history,ds)]
        page.update()
    def ingest(x):
        rid=x["router_id"]; history[rid].append(x); latest[rid]=x; h=list(history[rid])
        if len(h)>=3 and all(classify(v)=="CRITICAL" for v in h[-3:]) and rid not in sent:
            alerts.append({"time":x["timestamp"],"router_id":rid,"district":x["district"],"status":"CRITICAL","message":"Три последовательных критических измерения"}); sent.add(rid)
        if len(h)>=4 and all(h[i]["download_mbps"]>h[i+1]["download_mbps"] for i in range(-4,-1)) and rid+":trend" not in sent:
            alerts.append({"time":x["timestamp"],"router_id":rid,"district":x["district"],"status":"MEDIUM","message":"Тенденция снижения скорости загрузки"}); sent.add(rid+":trend")
    def tick():
        nonlocal index
        times=sorted({x["timestamp"] for x in source}); ts=times[index%len(times)]
        for x in source:
            if x["timestamp"]==ts: ingest(x)
        index+=1; stream_label.value=f"Поток активен · пакет {index} · {ts}"; render()
    def start(e):
        nonlocal running
        if running:return
        running=True
        def loop():
            nonlocal running
            while running:
                tick(); time.sleep({"5 секунд":5,"15 секунд":15,"60 секунд":60}.get(interval.value,5))
        threading.Thread(target=loop,daemon=True).start()
    def stop(e):
        nonlocal running
        running=False; stream_label.value="Поток остановлен"; page.update()
    def notify(text):
        bar=ft.SnackBar(ft.Text(text),duration=6000)
        try:
            page.show_dialog(bar)
        except Exception:
            page.snack_bar=bar; bar.open=True; page.update()
    def export(e):
        try:
            path = export_excel(latest, history, alerts)
            notify("Excel-отчёт сохранён: " + path)
            open_file(path)
        except PermissionError:
            notify("Не удалось сохранить Excel: файл открыт в другой программе. Закройте его и повторите.")
        except Exception as exc:
            notify(f"Не удалось создать Excel: {exc}")
    tile_map=TileMap(page,classify,color)
    def build_map_panel():
        legend=ft.Row([
            ft.Row([ft.Container(width=10,height=10,bgcolor=color(st),border_radius=8),ft.Text(label,size=11,color="#625D65")],spacing=5)
            for st,label in [("OK","Норма"),("MEDIUM","Предупреждение"),("CRITICAL","Критично")]
        ],wrap=True,spacing=18)
        controls=ft.Row([
            ft.IconButton(ft.Icons.ADD,tooltip="Приблизить",on_click=lambda e:tile_map.zoom_by(1)),
            ft.IconButton(ft.Icons.REMOVE,tooltip="Отдалить",on_click=lambda e:tile_map.zoom_by(-1)),
            ft.IconButton(ft.Icons.CENTER_FOCUS_STRONG,tooltip="Показать все роутеры",on_click=lambda e:tile_map.reset_view()),
            tile_map.zoom_text,
        ],spacing=2)
        return ft.Container(
            content=ft.Column([
                ft.Text("Карта размещения роутеров · Екатеринбург",size=17,weight=ft.FontWeight.W_600,color="#29272B"),
                ft.Text("Карта местности OpenStreetMap. Наведите курсор на маркер, чтобы увидеть адрес, статус и показатели.",size=11,color="#77727A"),
                ft.Row([legend,ft.Container(expand=True),controls],vertical_alignment=ft.CrossAxisAlignment.CENTER),
                tile_map.view,
                tile_map.status_text,
            ],spacing=10),
            padding=18,bgcolor="#FFFFFF",border=ft.Border.all(1,"#E7E5E8"),border_radius=14
        )
    map_panel=build_map_panel()
    def make_map(e):
        tile_map.failed.clear()
        tile_map.set_points(latest); tile_map.refresh()
        notify("Карта обновлена.")
    def open_browser_map(e):
        try:
            path=export_browser_map(latest,classify,BASE/"reports")
            notify("Интерактивная карта открыта в браузере: "+path)
        except Exception as exc:
            notify(f"Не удалось открыть карту: {exc}")

    for c in (status,district,search,pick): c.on_change=lambda e:render()

    panels = {
      "Обзор": ft.Column([summary,ft.Row([status,district,search],wrap=True),table],scroll=ft.ScrollMode.AUTO),
      "Аналитика и решения": ft.Column([districts_table,ft.Text("Рекомендации специалистам",size=18,weight=ft.FontWeight.W_600,color="#29272B"),advice],scroll=ft.ScrollMode.AUTO),
      "Диагностика": ft.Column([pick,history_view,diagnosis],scroll=ft.ScrollMode.AUTO),
      "Поток и оповещения": ft.Column([ft.Row([interval,ft.Button("Запустить",on_click=start),ft.Button("Остановить",on_click=stop)],wrap=True),stream_label,alert_view],scroll=ft.ScrollMode.AUTO),
      "Карта и Excel": ft.Column([ft.Row([ft.Button("Обновить карту",on_click=make_map),ft.Button("Открыть карту в браузере",on_click=open_browser_map),ft.Button("Выгрузить в Excel (.xlsx)",on_click=export)],wrap=True),map_panel],scroll=ft.ScrollMode.AUTO)
    }
    panel = ft.Container(content=panels["Обзор"], expand=True, padding=22, bgcolor="#F5F5F6", border_radius=16)
    nav_items = []
    def show_panel(name):
        panel.content = panels[name]
        for item_name, item in zip(panels.keys(), nav_items):
            item.bgcolor = "#FCEBF1" if item_name == name else "#FFFFFF"
        page.update()

    for name in panels:
        nav_items.append(
            ft.Container(
                content=ft.Text(name, size=14, color="#454148", weight=ft.FontWeight.W_600),
                padding=ft.Padding(16, 14, 12, 14),
                bgcolor="#FCEBF1" if name == "Обзор" else "#FFFFFF",
                border_radius=12,
                on_click=lambda e, n=name: show_panel(n),
                ink=True
            )
        )

    sidebar = ft.Container(
        width=245,
        bgcolor="#FFFFFF",
        border=ft.Border.only(right=ft.BorderSide(1, "#E7E5E8")),
        padding=18,
        content=ft.Column(
            [
                ft.Container(
                    content=ft.Column([
                        ft.Image(src=(BASE / "logo_k_telecom.jpeg").read_bytes(), width=205, height=62, fit=ft.BoxFit.CONTAIN),
                        ft.Text("МОНИТОРИНГ СЕТИ", size=10, color="#D21F5B", weight=ft.FontWeight.BOLD)
                    ], spacing=5),
                    padding=ft.Padding(6, 12, 6, 24)
                ),
                ft.Text("РАБОЧЕЕ ПРОСТРАНСТВО", size=10, color="#8D858D", weight=ft.FontWeight.BOLD),
                *nav_items,
                ft.Container(expand=True),
                ft.Container(
                    content=ft.Column([
                        ft.Text("СИСТЕМА МОНИТОРИНГА", size=10, color="#8D858D", weight=ft.FontWeight.BOLD),
                        ft.Text("Учебный прототип\nСинтетические данные", size=11, color="#77727A")
                    ], spacing=5),
                    padding=12,
                    bgcolor="#FCEBF1",
                    border_radius=10
                )
            ],
            expand=True,
            spacing=10
        )
    )

    workspace = ft.Column([
        ft.Container(
            content=ft.Row([
                ft.Column([
                    title,
                    ft.Text("Состояние сети • Екатеринбург и УрФО", size=13, color="#77727A")
                ], spacing=4),
                ft.Container(expand=True),
                ft.Container(
                    content=ft.Row([
                        ft.Container(width=8, height=8, bgcolor="#D21F5B", border_radius=10),
                        ft.Text("Демо-режим", size=12, color="#77727A")
                    ], spacing=8),
                    padding=ft.Padding(12, 8, 12, 8),
                    bgcolor="#FCEBF1",
                    border_radius=20
                )
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            padding=ft.Padding(30, 24, 30, 20),
            bgcolor="#FFFFFF",
            border=ft.Border.only(bottom=ft.BorderSide(1, "#E7E5E8"))
        ),
        panel
    ], expand=True, spacing=0)

    page.add(ft.Row([sidebar, workspace], expand=True, spacing=0, vertical_alignment=ft.CrossAxisAlignment.STRETCH))
    render()
ft.run(main)
