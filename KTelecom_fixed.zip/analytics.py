from collections import defaultdict
from math import radians,sin,cos,asin,sqrt

def classify(x):
    if x["ping_ms"]>200 or x["download_mbps"]<10 or x["upload_mbps"]<2 or x["packet_loss"]>=10 or x["jitter_ms"]>60: return "CRITICAL"
    if x["ping_ms"]>90 or x["download_mbps"]<50 or x["upload_mbps"]<10 or x["packet_loss"]>=3 or x["jitter_ms"]>30: return "MEDIUM"
    return "OK"

def haversine_km(a,b,c,d):
    R=6371; p=radians(c-a); q=radians(d-b)
    z=sin(p/2)**2+cos(radians(a))*cos(radians(c))*sin(q/2)**2
    return 2*R*asin(sqrt(z))

def diagnose(history,latest,rid):
    x=latest[rid]
    district=x["district"]
    if x["ping_ms"]>90 and x["packet_loss"]>=3: msg="Вероятны проблемы с качеством канала связи: высокие ping и packet loss."
    elif x["jitter_ms"]>30 and x["packet_loss"]>=3: msg="Вероятна нестабильность соединения: высокие jitter и packet loss."
    elif x["download_mbps"]<50 and x["ping_ms"]<=90: msg="Возможно ограничение пропускной способности или высокая нагрузка."
    elif sum(1 for v in latest.values() if v["district"]==district and classify(v)!="OK")>=2: msg="Возможна проблема сетевого оборудования или общего канала района."
    else: msg="Причина по текущим правилам не определена; продолжить наблюдение."
    return msg+" Причина предположительная, требуется дополнительная проверка."

def analyze_network(latest,histories):
    groups=defaultdict(list)
    for rid,x in latest.items(): groups[x["district"]].append(x)
    out=[]
    for district,items in groups.items():
        states=[classify(x) for x in items]; problem=sum(s!="OK" for s in states); critical=states.count("CRITICAL")
        out.append({"district":district,"total":len(items),"problem":problem,"critical":critical,
                    "share":100*problem/len(items),"priority":"HIGH" if critical>=2 else "MEDIUM" if problem else "LOW"})
    return sorted(out,key=lambda d:({"HIGH":0,"MEDIUM":1,"LOW":2}[d["priority"]],-d["share"]))

def recommendations(latest,histories,districts):
    high={d["district"] for d in districts if d["priority"]=="HIGH"}; out=[]
    for rid,x in latest.items():
        h=list(histories[rid]); s=classify(x)
        if x["district"] in high: rec="Инициировать проверку сетевого оборудования района"
        elif s=="CRITICAL" and len(h)>=5 and all(classify(v)=="CRITICAL" for v in h[-5:]): rec="Рассмотреть необходимость выезда бригады"
        elif s=="CRITICAL": rec="Передать заявку техническому специалисту"
        elif s=="MEDIUM": rec="Провести удалённую диагностику"
        else: rec="Продолжить наблюдение"
        out.append((rid,rec))
    return out
