from datetime import datetime
def validate(row,seen):
    required=("router_id","location","district","lat","lon","timestamp","ping_ms","download_mbps","upload_mbps","packet_loss","jitter_ms")
    errors=[]
    for k in required:
        if k not in row or row[k] in ("",None): errors.append("Нет поля "+k)
    for k in ("lat","lon","ping_ms","download_mbps","upload_mbps","packet_loss","jitter_ms"):
        try:
            if float(row[k])<0: errors.append("Отрицательное значение "+k)
        except (ValueError,KeyError,TypeError): errors.append("Некорректное число "+k)
    try: datetime.fromisoformat(row["timestamp"])
    except Exception: errors.append("Некорректная временная метка")
    key=(row.get("router_id"),row.get("timestamp"))
    if key in seen: errors.append("Повторяющееся измерение")
    seen.add(key)
    return errors
